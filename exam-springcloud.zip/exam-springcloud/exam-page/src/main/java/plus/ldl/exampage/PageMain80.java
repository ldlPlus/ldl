package plus.ldl.exampage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author ldl.plus
 * @date 2020年05月14日  18:43
 */
@SpringBootApplication
public class PageMain80 {
    public static void main(String[] args) {
        SpringApplication.run(PageMain80.class, args);
    }
}
